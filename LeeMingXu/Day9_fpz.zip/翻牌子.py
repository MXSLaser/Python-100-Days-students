from tkinter import *
import random
import pygame
from pygame.locals import *
import sys
import time


pygame.init()
root = Tk()
root.wm_attributes('-topmost',1)

defaultimage = "images/craddefault.png"
class Card(pygame.sprite.Sprite):                   #卡片列表
    def __init__(self, image, position, value):
        pygame.sprite.Sprite.__init__(self)
        self.cardimage = pygame.image.load(defaultimage).convert_alpha()
        self.image = image
        self.rect = self.cardimage.get_rect()
        self.rect.left, self.rect.top = position
        self.value = value
        self.clicked = False

    def click(self):
        self.cardimage = pygame.image.load(self.image).convert_alpha()
        self.clicked = True

    def declick(self):
        self.cardimage = pygame.image.load(defaultimage).convert_alpha()
        self.clicked = False

    def getPos(self):
        return self.rect.left, self.rect.top
    
    def getClickstate(self):
        return self.clicked

    def getvalue(self):
        return self.value
        


def callback():
    sys.exit()

def coliderCheck(mouse,target):
    mousex,mousey = mouse
    for each in target:
        cardx,cardy = each.getPos()
        if (not each.getClickstate()) and 0<mousex-cardx<140 and 0<mousey-cardy<140:
            each.click()
            return each

judgements = []
def judge(card):
    if len(judgements)==2:
        #print(judgements)
        if judgements[0].getvalue()!=judgements[1].getvalue():
            for each in judgements:
                each.declick()
            del(judgements[0])
            del(judgements[0])
        else:
            del(judgements[0])
            del(judgements[0])
    if card != None:
        judgements.append(card)

def is_win(cards):
    for each in cards:
        if not each.getClickstate():
            return False
    return True

photos = ["images/c.png","images/c++.png",
          "images/c#.png","images/python.png",
          "images/java.png","images/lua.png"]


def game():
    root.withdraw() #****实现主窗口隐藏
    root.update()
    clicks = 0
    #生成随级卡片位置
    values = [0,0,1,1,2,2,3,3,4,4,5,5]
    random.shuffle(values)

    #屏幕大小设定
    size = width, height = 735, 600
    screen = pygame.display.set_mode(size)

    #cards数组创建
    x = 35
    y = 35
    cards = []
    for i in range(0,12):
        position = x,y
        card = Card(photos[values[i]], position, values[i])
        cards.append(card)
        if (i+1)%4==0:
            y += 5*35
            x = 35
        else:
            x += 35*5
            #print(position)


    position = 735//2-35,550
    #背景创建
    bg = (200, 20, 100)
    pygame.display.set_caption("我今天就要翻编程！！！")
    font = pygame.font.Font(None, 40)

    #主游戏进程
    clock = pygame.time.Clock()
    while True:
        text = "Flips:"+str(clicks)
        for event in pygame.event.get():
            if event.type == QUIT:
                Button3.pack()
                pygame.exit()
                sys.exit()
                mainloop()
            if event.type == MOUSEBUTTONDOWN:
                card = coliderCheck(event.pos,cards)
                b1 = judge(card)      
                if card!=None:
                    clicks+=1
        screen.fill(bg)
        for each in cards:
            screen.blit(each.cardimage , each.rect)
        screen.blit(font.render(text,True,(0,0,0)) , position)
        pygame.display.flip()
        if is_win(cards):
            text = "You win! And your total flips is "+str(clicks)
            position = 735//2-140,500
            var.set("您已获胜！")
            Button1.pack()
            Button2.pack()
            mainloop()
            return
        clock.tick(60)



#按钮
frame1 = Frame(root)
frame2 = Frame(root)

var = StringVar()
var.set("您已经退出游戏！")
textLabel = Label(root,
                  textvariable = var,
                  justify = LEFT,
                  padx = 10)
textLabel.pack(side = LEFT)

Button1 = Button(frame2, text = "退出",command = callback)

Button3 = Button(frame2, text = "确认",command = game)

Button2 = Button(frame2, text = "再玩一次",command = game)

frame2.pack(padx = 10, pady = 10)



if __name__=='__main__':
    game()
#mainloop()

